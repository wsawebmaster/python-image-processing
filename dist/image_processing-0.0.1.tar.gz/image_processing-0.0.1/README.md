# 📂 Desenvolvendo um Pacote de Processamento de Imagens com Python

## 📃 Descrição

Desenvolvido durante participação do Bootcamp Suzano - Python Developer na plataforma DIO
O pacote image_processing é usado para:
	Processamento:
		- Correspondência de histograma
		- Similaridade estrutural
		- Redimensionar imagem
	Utilitários:
		- Ler imagem
		- Salvar imagem
		- Plotar imagem
		- Plotar resultado
		- Plotar histograma

## 🚀 Tecnologias Utilizadas

- Python
- Pypi
- Git e Github

## Links uteis de documentação

[pip](https://pip.pypa.io/en/stable/) para instalar o package_name
[setup.py](https://setuptools.readthedocs.io/en/latest/setuptools.html)

### Comandos de instalação

	pip install -r requirements.txt

	python -m pip install --upgrade pip
	python -m pip install --user twine
	python -m pip install --user setuptools

### Comando para criar distribuições

	python setup.py sdist bdist_wheel

---
---

### 📧 Contato

[LinkedIn](https://www.linkedin.com/in/wsawebmaster/)

[wsawebmaster@yahoo.com.br](mailto:wsawebmaster@yahoo.com.br)